# Anderson Home Library — Codex data handoff

**Dated:** November 21, 2026  
**Collection:** Anderson Home Library  
**Owner verification:** Physical-book identification, shelf positions, and binding/edition observations were reviewed and confirmed by the owner during the inventory.

## Contents

- `catalog/books.csv` and `catalog/books.json` — original 564 physical-book records from the library master inventory; identifiers and source fields retained.
- `catalog/Anderson_Home_Library_Photo_Confirmed.xlsx` — original master workbook.
- `pretty_side/locations.csv` and `pretty_side/locations.json` — 142 individually identified, front-facing physical-book placements across all 24 cubbies, P01–P24.
- `pretty_side/location_summary.csv` — positions and physical-volume counts for all 24 cubbies.
- `owner_confirmed_details.csv` — additional owner-confirmed corrections, bibliographic details, format and edition notes.
- `display_and_edition_notes.csv` — concise key collection observations.
- `catalog/reference_and_audits.json` and `catalog/*_audit.csv` / reference CSVs — original detailed identification and audit material.

## Verified collection structure

The 564-record catalog and 142-location Pretty Side inventory are **different views of overlapping physical books**. Do not add the 142 location entries to 564 as if each were a new acquisition. P01 illustrated *Mockingjay* was a new purchase. Other Pretty Side entries generally represent existing objects placed on their new display shelves. The original `Shelf Code` in master records reflects an earlier shelf arrangement, while `pretty_side/locations.csv` reflects the owner-confirmed current positions. Match physical copies by edition and binding, not by title alone. Where a unique match is not established, preserve both records for review rather than guessing.

Position order: P01 is upper-left; proceed left-to-right, top-to-bottom; P24 is lower-right. There are four columns and six rows. **All 24 positions are present.**

Count one physical bound volume as one item. A collection, boxed set, omnibus, or multi-novel hardcover can contain multiple searchable constituent works without increasing the physical-book count. Keep separate physical editions separate: this includes two Inheritance Cycle sets, duplicate Keeper of the Lost Cities titles, and various editions of Percy Jackson / Kane Chronicles. Shelf decor (amethyst, geodes, display stones) is not book inventory. Do not identify hidden books visible only behind the two-sided shelves.

The source workbook includes 564 catalogued records. New owner-supplied details are not proof that every `catalog/books` row has been independently cross-matched to a precise current cubby. The Pretty Side map covers only the front-facing Pretty Side cubbies, not the entire house collection. Unconfirmed edition, author, binding, or location fields should remain unconfirmed.

### Format labels

Hardcover / Paperback / Spiral-bound are physical bindings. “Clothbound” or “sprayed-edge” can also describe cover/finish, rather than replacing the structural binding. Owner corrections take priority for the specific copies photographed.

### Reader’s Digest

P06 contains **11** physical condensed-book volumes. P10 contains **6** more. The non-numbered volumes are still identifiable by the contained titles “A Falcon for a Queen” and “The Waltz Kings”. Preserve the multi-work contents within each physical item.

### Collection highlights

P03 contains two distinct complete four-volume *Inheritance Cycle* sets plus *Murtagh* (9 physical books). P15 and P16 are two distinct Ranger’s Apprentice/related shelves. P21 contains *The Fury of the Gods* (hardcover), while P22 holds the six mythology hardcovers. P23 and P24 complete the display.

## Verification checks performed

- All 24 location codes P01–P24 present, no duplicate `(position, sequence)` identifiers.
- 142 individual location rows; no blank titles and no unspecified binding in the photographed display list.
- P06 contains 11 Reader’s Digest books; P03 contains nine Inheritance books; P15 and P16 are separate (12 and 7); P21 and P22 both populated.
- The source catalog contains exactly 564 entries in both CSV and JSON.
- Files within the package tested for opening and the packaged JSON/CSV counts confirmed.

